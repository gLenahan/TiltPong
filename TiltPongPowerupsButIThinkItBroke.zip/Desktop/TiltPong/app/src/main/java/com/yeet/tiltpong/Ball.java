package com.yeet.tiltpong;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;
public class Ball extends View {
        private Bitmap ball;
        private int canvasWidth, canvasHeight;
        private com.yeet.tiltpong.Position pos;
        private boolean touchP = false;

        public Ball(Context context) {
            super(context);
            ball = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
            pos = new Position();
            pos.setBoth(11, 100);
        }
    public void setPos(int x, int y)
    {
        pos.setBoth(x, y);
    }

    public int getPX()
    {
        return pos.x();
    }

    public int getPY()
    {
        return pos.y();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvasWidth = canvas.getWidth();
        canvasHeight = canvas.getHeight();
        ball = Bitmap.createScaledBitmap(ball, (int)(canvasWidth * 0.05), (int)(canvasHeight * 0.2), true);
        pos.setX((int)(canvasWidth * 0.8));

        //  canvas.drawBitmap(backgroundImage, 0, 0, null);


        int minX = 0;
        int maxX = canvasWidth;

        if(pos.x() < minX);
        {
            pos.setX(minX);
        }
        if(pos.x() > maxX)
        {
            pos.setX(maxX);
        }


        if(touchP)
        {
            pos.setX(pos.x() - 10);
        }


        canvas.drawBitmap(ball, pos.x(), pos.y(), null);
    }
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN)
        {
            if((int)event.getX() <= canvasWidth/2)
            {
                touchP = true;
            }
            else
            {
                touchP = false;
            }
        }
        if(event.getAction() == MotionEvent.ACTION_UP)
        {
            if((int)event.getX() <= canvasWidth/2)
            {
                touchP = false;
            }
            else
            {
                touchP = true;
            }
        }
        return true;
    }
}
