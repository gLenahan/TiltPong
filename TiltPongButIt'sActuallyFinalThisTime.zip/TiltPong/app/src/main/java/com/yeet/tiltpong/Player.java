package com.yeet.tiltpong;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

public class Player extends View
{
    private Bitmap paddle;
    private Bitmap ball;
    private Bitmap paddleTwoElectricBoogaloo;
    private Bitmap bck;
    private Paint scoreP = new Paint();
    private int direction;
    private int canvasWidth, canvasHeight;
    private Position pos, posb;
    private Position posEnemy;
    private boolean touchL, touchR = false;
    private int check;
    private int score1, score2;
    private int paddleSpeed, ballSpeed;
    private int ballSpeedUpTimer;

    public Player(Context context)
    {
        super(context);
        paddleTwoElectricBoogaloo = BitmapFactory.decodeResource(getResources(), R.drawable.paddle);
        paddle = BitmapFactory.decodeResource(getResources(), R.drawable.paddle);
        ball = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
        bck = BitmapFactory.decodeResource(getResources(), R.drawable.bblack);
        pos = new Position(10, 500);
        posb = new Position(11, 500);
        posEnemy = new Position(10, 500);
        scoreP.setColor(Color.WHITE);
        scoreP.setTypeface(Typeface.DEFAULT_BOLD);
        scoreP.setAntiAlias(true);
        int dirRan = (int)(Math.random() * 4) + 1;
        score1 = 0;
        score2 = 0;
        paddleSpeed = 0;
        ballSpeed = 0;
        ballSpeedUpTimer = 0;
        switch(dirRan)
        {
            case 1:
                direction = 45;
                break;
            case 2:
                direction = 135;
                break;
            case 3:
                direction = 225;
                break;
            case 4:
                direction = 315;
                break;
        }
        check = 0;
    }


    public void setPos(int x, int y)
    {
        pos.setBoth(x, y);
    }

    public int getPX()
    {
        return pos.x();
    }

    public int getPY()
    {
        return pos.y();
    }

    public void setPosB(int x, int y)
    {
        posb.setBoth(x, y);
    }

    public int getBX()
    {
        return posb.x();
    }

    public int getBY()
    {
        return posb.y();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvasWidth = canvas.getWidth();
        canvasHeight = canvas.getHeight();
        paddleTwoElectricBoogaloo = Bitmap.createScaledBitmap(paddle, (int)(canvasWidth * 0.05), (int)(canvasHeight * 0.2), true);
        paddle = Bitmap.createScaledBitmap(paddle, (int)(canvasWidth * 0.05), (int)(canvasHeight * 0.2), true);
        ball = Bitmap.createScaledBitmap(ball, (int)(canvasHeight * 0.05), (int)(canvasHeight * 0.05), true);
        pos.setX((int)(canvasWidth * 0.08));
        posEnemy.setX((int)(canvasWidth * 0.85));
        scoreP.setTextSize(canvasHeight/15);
        if(check == 0)
        {
            posb.setX((int) (canvasWidth / 2));
            posb.setY(((int)(Math.random() * canvasHeight - 20)) + 20);
            check++;
            ballSpeed = (int) (canvasHeight * 0.02);
            paddleSpeed = (int)(canvasHeight * 0.015);
        }

        ballSpeedUpTimer++;
        if(ballSpeedUpTimer % 10 == 0)
        {
            ballSpeed += 1;
        }
        int random = (int)(Math.random() * 10);
        if(random == 7) posb.setX(posb.x() + 2);

        int minY = 0;
        int maxY = canvasHeight - paddle.getHeight();

        int minPaddleTwoBoogalooY = 0;
        int maxPaddleTwoBoogalooY = canvasHeight - paddle.getHeight();


        int minbY = 0;
        int maxbY = canvasHeight - ball.getHeight();

        if(posb.y() < minbY)
        {
            posb.setY(minbY);
            if(direction == 315) direction = 45;
            if(direction == 225) direction = 135;
        }
        if(posb.y() > maxbY)
        {
            posb.setY(maxbY);
            if(direction == 45) direction = 315;
            if(direction == 135) direction = 225;
        }

        switch(direction) {
            case 45:
                posb.setX(posb.x() + ballSpeed);
                posb.setY(posb.y() + ballSpeed);
                break;
            case 135:
                posb.setX(posb.x() - ballSpeed);
                posb.setY(posb.y() + ballSpeed);
                break;
            case 225:
                posb.setX(posb.x() - ballSpeed);
                posb.setY(posb.y() - ballSpeed);
                break;
            case 315:
                posb.setX(posb.x() + ballSpeed);
                posb.setY(posb.y() - ballSpeed);
        }

        if(posb.x() <= canvasWidth * 0.11 && posb.x() >= canvasWidth * 0.09)
        {
            if(posb.y() >= pos.y() && posb.y() <= pos.y() + paddle.getHeight())
            {
                if(direction == 225) direction = 315;
                if(direction == 135) direction = 45;
            }
        }

        if(posb.x() >= canvasWidth * 0.85 && posb.x() <= canvasWidth * 0.87)
        {
            if(posb.y() >= posEnemy.y() && posb.y() <= posEnemy.y() + paddleTwoElectricBoogaloo.getHeight())
            {
                if(direction == 315) direction = 225;
                if(direction == 45) direction = 135;
            }
        }

        if(pos.y() < minY)
        {
            pos.setY(minY);
        }
        if(pos.y() > maxY)
        {
            pos.setY(maxY);
        }


        if(touchL)
        {
            posEnemy.setY(pos.y() - paddleSpeed);
            pos.setY(pos.y() - paddleSpeed);
        }
        if(touchR)
        {
            posEnemy.setY(pos.y() + paddleSpeed);
            pos.setY(pos.y() + paddleSpeed);
        }

        if(posb.x() < 0)
        {
            score2++;
            posb.setX(canvasWidth / 2);
            ballSpeed = (int) (canvasHeight * 0.02);
        }
        if(posb.x() > canvasWidth)
        {
            score1++;
            posb.setX(canvasWidth / 2);
            ballSpeed = (int) (canvasHeight * 0.02);
        }

        canvas.drawBitmap(bck, 0, 0, null);
        canvas.drawBitmap(paddle, pos.x(), pos.y(), null);
        canvas.drawBitmap(paddleTwoElectricBoogaloo, posEnemy.x(), posEnemy.y(), null);
        canvas.drawBitmap(ball, posb.x(), posb.y(), null);
        canvas.drawText("P1 Score: " + score1,  canvasWidth/2, (float) (canvasHeight * 0.05), scoreP);
        canvas.drawText("P2 Score: " + score2,  canvasWidth/2, (float) (canvasHeight * 0.1), scoreP);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN)
        {
            if((int)event.getX() <= canvasWidth/2)
            {
                touchL = true;
            }
            else
            {
                touchR = true;
            }
        }
        if(event.getAction() == MotionEvent.ACTION_UP)
        {
            if((int)event.getX() <= canvasWidth/2)
            {
                touchL = false;
            }
            else
            {
                touchR = false;
            }
        }
        return true;
    }
}
