package com.yeet.tiltpong;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;

public class Ball extends View {
    private Bitmap ball;
    private int canvasWidth, canvasHeight;
    private com.yeet.tiltpong.Position posb;
    private int direction;
    private boolean touchP = false;

    public Ball(Context context)
    {
        super(context);

        ball = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
        posb = new Position();
        posb.setBoth(11, 500);
        int dirChoice = (int)(Math.random() * 2);
        if(dirChoice == 0)
        {
            direction = 315;
        }
        else
        {
            direction = 225;
        }
    }

    public void setPosB(int x, int y)
    {
        posb.setBoth(x, y);
    }

    public int getBX()
    {
        return posb.x();
    }

    public int getBY()
    {
        return posb.y();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvasWidth = canvas.getWidth();
        canvasHeight = canvas.getHeight();
        ball = Bitmap.createScaledBitmap(ball, (int)(canvasHeight * 0.05), (int)(canvasHeight * 0.05), true);
        posb.setX((int)(canvasWidth/2));

        int minbY = 0;
        int maxbY = canvasHeight - ball.getHeight();

        if(posb.x() < minbY)
        {
            posb.setX(minbY);
            if(direction == 315) direction = 45;
            if(direction == 225) direction = 135;
        }
        if(posb.x() > maxbY)
        {
            posb.setX(maxbY);
            if(direction == 45) direction = 315;
            if(direction == 135) direction = 225;
        }

        switch(direction) {
            case 45:
                posb.setX(posb.x() + 10);
                posb.setY(posb.y() - 10);
                break;
            case 135:
                posb.setX(posb.x() - 10);
                posb.setY(posb.y() - 10);
                break;
            case 225:
                posb.setX(posb.x() - 10);
                posb.setY(posb.y() + 10);
                break;
            case 315:
                posb.setX(posb.x() + 10);
                posb.setY(posb.y() + 10);
        }
/*
        if(pos.x() <= canvasWidth * 0.08)
        {
            if(pos.y() < Player.getPY() && pos.y() > player.)
        }*/

        canvas.drawBitmap(ball, posb.x(), posb.y(), null);
    }


}


