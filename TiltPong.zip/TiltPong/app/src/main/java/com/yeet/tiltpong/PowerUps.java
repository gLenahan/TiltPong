package com.yeet.tiltpong;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;
public class PowerUps extends View{
    private Bitmap powerupLogo;
    //  private Bitmap backgroundImage;
    private int canvasWidth, canvasHeight;
    private Position pos;


    public PowerUps(Context context)
    {
        super(context);

        powerupLogo = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
        //  backgroundImage = BitmapFactory.decodeResource(getResources(), R.drawable.blackbutlower);
        pos = new Position();
        pos.setBoth(5, 500);
    }

    public void setPos(int x, int y)
    {
        pos.setBoth(x, y);
    }

    public int getPX()
    {
        return pos.x();
    }

    public int getPY()
    {
        return pos.y();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvasWidth = canvas.getWidth();
        canvasHeight = canvas.getHeight();
        powerupLogo = Bitmap.createScaledBitmap(powerupLogo, (int)(canvasWidth * 0.05), (int)(canvasHeight * 0.2), true);
        pos.setX((int)(canvasWidth * 0.8));

        //  canvas.drawBitmap(backgroundImage, 0, 0, null);






        canvas.drawBitmap(powerupLogo, pos.x(), pos.y(), null);
    }



}
