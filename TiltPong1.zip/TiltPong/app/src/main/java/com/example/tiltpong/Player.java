package com.example.tiltpong;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;

public class Player extends View
{
    private Bitmap paddle;
  //  private Bitmap backgroundImage;
    private int canvasWidth, canvasHeight;
    private Position pos;
    private boolean touchL, touchR = false;

    public Player(Context context)
    {
        super(context);

        paddle = BitmapFactory.decodeResource(getResources(), R.drawable.paddle);
      //  backgroundImage = BitmapFactory.decodeResource(getResources(), R.drawable.blackbutlower);
        pos = new Position();
        pos.setBoth(10, 500);
    }

    public void setPos(int x, int y)
    {
        pos.setBoth(x, y);
    }

    public int getPX()
    {
        return pos.x();
    }

    public int getPY()
    {
        return pos.y();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvasWidth = canvas.getWidth();
        canvasHeight = canvas.getHeight();
        paddle = Bitmap.createScaledBitmap(paddle, (int)(canvasWidth * 0.05), (int)(canvasHeight * 0.2), true);
        pos.setX((int)(canvasWidth * 0.8));

      //  canvas.drawBitmap(backgroundImage, 0, 0, null);

        int minY = 0;
        int maxY = canvasHeight - paddle.getHeight();

        if(pos.y() < minY)
        {
            pos.setY(minY);
        }
        if(pos.y() > maxY)
        {
            pos.setY(maxY);
        }


        if(touchL)
        {
            pos.setY(pos.y() - 10);
        }
        if(touchR)
        {
            pos.setY(pos.y() + 10);
        }

        canvas.drawBitmap(paddle, pos.x(), pos.y(), null);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN)
        {
            if((int)event.getX() <= canvasWidth/2)
            {
                touchL = true;
            }
            else
            {
                touchR = true;
            }
        }
        if(event.getAction() == MotionEvent.ACTION_UP)
        {
            if((int)event.getX() <= canvasWidth/2)
            {
                touchL = false;
            }
            else
            {
                touchR = false;
            }
        }
        return true;
    }
}
